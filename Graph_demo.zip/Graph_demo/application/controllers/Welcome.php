<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->Model('ScoreModel');
	}
	public function index()
	{
		$this->load->view('graph');
	}
	public function fetch_score()
	{
		$data = array();
		$score = $this->ScoreModel->get_data(array("playerid","score","month"));


		foreach($score as $row){
			$data[] = $row;
		}
		// var_dump($score);
		echo json_encode($data);
	}
	public function fetch_followers()
	{
		$follow = array();
		$followers = $this->ScoreModel->get_data_followers(array("id","fname","facebook","twitter","googleplus"));
		foreach($followers as $row){
			$follow[] = $row;
		}
		echo json_encode($follow);
	}
}
