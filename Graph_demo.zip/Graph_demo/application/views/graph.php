<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>graph</title>
    <script src="<?php echo base_url()?>assets/js//Chart.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
    <style>
    .chart-container{
        width:640px;
        height:auto;
    }
    </style>
</head>
<body>
    <div class="row">
        <div class="col">
            <div class="chart-container">
                <h1 align="center">Bar Graph</h1>
                <canvas id="mycanvas"></canvas>
            </div>
        </div>
        <div class="col">
            <div class="chart-container">
                <h1 align="center">Pie Chart</h1>
                <canvas id="mycanvaspie"></canvas>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <div class="chart-container">
                <h1 align="center">Line Chart</h1>
                <canvas id="mycanvasline"></canvas>
            </div>
        </div>
    </div>


</body>
<script>;
    $(document).ready(function(){

  $.ajax({
    url: "<?php echo base_url()?>Welcome/fetch_score",
    method: "POST",
    dataType:'json',
    success: function(data)
    {
        var player = [];
      var score = [];
        var month = [];
      for(var i = 0;i<data.length; i++) {
        //   console.log(data[i].month);
        player.push(data[i].playerid);
        month.push(data[i].month);
        // score.push(data[i].score);
        score.push(data[i].score);
      }

      var chartdata = {
        labels: month,
        datasets : [
          {
            label: 'Month Score',
            backgroundColor: 'rgba(255, 0, 0, 0.75)',
            borderColor: 'rgba(255, 0, 0, 0.75)',
            hoverBackgroundColor: 'rgba(255, 0, 0, 1)',
            hoverBorderColor: 'rgba(255, 0, 0, 1)',
            data:score
          }
        ]
      };
      var piedata = {
        labels: month,
        datasets : [
          {
            label: 'Month Score',
            backgroundColor: 'rgba(0, 0, 255, 0.75)',
            borderColor: 'rgba(0, 0, 255, 0.75)',
            hoverBackgroundColor: 'rgba(0, 0, 255, 1)',
            hoverBorderColor: 'rgba(0, 0, 255, 1)',
            data:score
          }
        ]
      };


      var ctx = $("#mycanvas");
      var ctxpie = $("#mycanvaspie");

      var pieGraph = new Chart(ctx, {
        type: 'bar',
        data: chartdata
      });
      var barGraph = new Chart(ctxpie, {
        type: 'pie',
        data: piedata
      });
    }
  });
  lineGraph();
});
function lineGraph()
{
    $.ajax({
        url:"<?php echo base_url()?>Welcome/fetch_followers",
        method: "POST",
        dataType:'json',
        success:function(data){
            var fname = [];
            var facebook = [];
            var googleplus = [];
            var twitter =[];
            for(var i = 0;i<data.length; i++) {
                fname.push("fname ="+data[i].fname);
                facebook.push(data[i].facebook);
                googleplus.push(data[i].googleplus);
                twitter.push(data[i].twitter);
            }
            var linedata = {
                    labels: fname,
                    datasets :
                    [
                        {
                            label: 'Facebook',
                            fill:false,
                            lineTension:0.2,
                            backgroundColor: 'rgba(0, 255, 0, 0.75)',
                            borderColor: 'rgba(0, 255, 0, 0.75)',
                            hoverBackgroundColor: 'rgba(0, 255, 0, 1)',
                            hoverBorderColor: 'rgba(0, 255, 0, 1)',
                            data:facebook
                        },
                        {
                            label: 'GooglePlus',
                            fill:false,
                            lineTension:0.1,
                            backgroundColor: 'rgba(0, 0, 255, 0.75)',
                            borderColor: 'rgba(0, 0, 255, 0.75)',
                            hoverBackgroundColor: 'rgba(0, 0, 255, 1)',
                            hoverBorderColor: 'rgba(0, 0, 255, 1)',
                            data:googleplus
                        },
                        {
                            label: 'Twitter',
                            fill:false,
                            lineTension:0.1,
                            backgroundColor: 'rgba(255, 0, 0, 0.75)',
                            borderColor: 'rgba(255, 0, 0, 0.75)',
                            hoverBackgroundColor: 'rgba(255, 0, 0, 1)',
                            hoverBorderColor: 'rgba(255, 0, 0, 1)',
                            data:twitter
                        },

                    ]
            };
            var ctx = $('#mycanvasline');
            var lineGraph = new Chart(ctx, {
                type: 'line',
                data: linedata
            });

        }
    });
}
</script>
</html>