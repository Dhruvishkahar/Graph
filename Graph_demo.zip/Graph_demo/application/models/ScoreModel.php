<?php

class ScoreModel extends CI_Model
{
    public function __construct()
    {

    }
    public function get_data($selectarray)
    {
        if($selectarray != null)
        {
            if(is_array($selectarray))
            {
                foreach ($selectarray as $key => $value) {
                    $this->db->select($value);
                }
            }
        }
        // $this->db->select('playerid as player');
        // $this->db->select('score as score');
        $this->db->order_by('playerid',"desc");
        $res = $this->db->get('score');
        return $res->result();

    }
    public function get_data_followers($selectarray)
    {
        if($selectarray != null)
        {
            if(is_array($selectarray))
            {
                foreach ($selectarray as $key => $value) {
                    $this->db->select($value);
                }
            }
        }
        $res =$this->db->get('followers');
        return $res->result();
    }
}
?>